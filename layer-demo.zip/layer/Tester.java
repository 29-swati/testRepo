package com.hsbc.layer;

public class Tester {
	
	public static void main(String[] args) {
		BookUI ui = new BookUI();
		ui.displayMenu();
	}

}
