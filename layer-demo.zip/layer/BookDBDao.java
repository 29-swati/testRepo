package com.hsbc.layer;

public class BookDBDao implements BookDao {

	//deals with Database like MySql
	
	@Override
	public void addBook(Book b) {
		// TODO Auto-generated method stub

	}

	@Override
	public Book[] getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book findBookById(int bid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book[] findBookByAuthor(String author) {
		// TODO Auto-generated method stub
		return null;
	}

}
