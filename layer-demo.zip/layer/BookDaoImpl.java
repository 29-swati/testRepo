package com.hsbc.layer;

import java.util.Arrays;

public class BookDaoImpl implements BookDao{
	
	Book[] books = new Book[5];
	
	public BookDaoImpl() {
		books[0] = new Book(1001,"Java","Shrilata", 400.0);
		books[1] = new Book(1002,"Servlet","Anita", 500.0);
		books[2] = new Book(1003,"JSP","Soha", 300.0);
		books[3] = new Book(1004,"Javascript","Shrilata", 400.0);
		books[4] = new Book(1005,"Spring","Anita", 450.0); 
	}
	
	public Book[] getAllBooks() {
		return books;
	}
	
	public Book findBookById(int bid) {
		Book b = null;
		
		for(Book book : books ) {
			if(book.getBookId() == bid) {
				b = book;
				break;
			}	
		}
		return b;
	}
	
	public Book[] findBookByAuthor(String author) {
		
		int count=0;
		
		for(Book book : books) {
			if(book.getAuthor().equals(author))
				count++;
		}
		
		Book[]  authBook = new Book[count];
		int i = 0;
		
		for(Book book : books) {
			if(book.getAuthor().equals(author)) {
				authBook[i] = book;
			    i++;
			}
		}
		
		return authBook;
	}
	
	public void addBook(Book b) {
		books = Arrays.copyOf(books, books.length+1);
		books[books.length-1] = b;
	}
	
}














