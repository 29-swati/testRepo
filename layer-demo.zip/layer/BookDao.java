package com.hsbc.layer;

public interface BookDao {

	public void addBook(Book b);

	public Book[] getAllBooks();

	public Book findBookById(int bid);

	public Book[] findBookByAuthor(String author);

}
