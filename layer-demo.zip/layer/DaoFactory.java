package com.hsbc.layer;

public class DaoFactory {

	public static BookDaoImpl getArrayDao() {
		return new BookDaoImpl();
	}

	/*
	BookDao bookDao;

	public static BookDao getDao(String type) {
		if (type.equals("array"))
			return new BookDaoImpl();
		else if (type.equals("collection"))
			return new BookCollDao();
		else
			return new BookDBDao();
	}
	*/

}
