package com.hsbc.layer;

import java.util.Arrays;
import java.util.Scanner;

public class BookUI {

	BookDao dao = null;
	Scanner sc = null;

	public BookUI() {
		sc = new Scanner(System.in);
		// System.out.println("Enter size of data store");
		// int size = sc.nextInt();
		// Book[] bookarr = ArrayStoreFactory.getStore(size);
		// dao = new BookDaoImpl1(bookarr);

		dao = DaoFactory.getArrayDao();
	}

	public void displayMenu() {
		while (true) {
			System.out.println("\n ----------User Menu-------------");
			System.out.println("1. Add Book");
			System.out.println("2. Fetch all Books");
			System.out.println("3. Fetch Book by id");
			System.out.println("4. Fetch book by author");
			System.out.println("5. Exit application");

			System.out.println("Enter your choice");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				dao.addBook(acceptBookDetails());
				break;
			case 2:
				Book[] allbooks = dao.getAllBooks();
				for (Book book : allbooks)
					book.displayDetails();
				break;
			case 3:
				System.out.println("Enter Book to search");
				int id = sc.nextInt();
				Book b = dao.findBookById(id);
				if (b != null)
					System.out.println("Book found : " + b);
				else
					System.out.println("Book with id " + id + " not found");
				break;
			case 4:
				System.out.println("Enter author to search");
				String author = sc.next();
				Book[] booksByAuth = dao.findBookByAuthor(author);
				for (Book book : booksByAuth)
					book.displayDetails();
				break;
			case 5:
				System.exit(0);
			}
		}
	}

	private Book acceptBookDetails() {
		System.out.println("Enter Book id");
		int bid = sc.nextInt();
		System.out.println("Enter Book name");
		String bname = sc.next();
		System.out.println("Enter Book author");
		String author = sc.next();
		System.out.println("Enter Book price");
		double price = sc.nextDouble();
		Book b = new Book(bid, bname, author, price);
		return b;
	}
}
