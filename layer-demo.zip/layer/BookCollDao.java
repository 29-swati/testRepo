package com.hsbc.layer;

public class BookCollDao implements BookDao {

	//deals with collection like ArrayList
	
	@Override
	public void addBook(Book b) {
		// TODO Auto-generated method stub

	}

	@Override
	public Book[] getAllBooks() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book findBookById(int bid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book[] findBookByAuthor(String author) {
		// TODO Auto-generated method stub
		return null;
	}

}
