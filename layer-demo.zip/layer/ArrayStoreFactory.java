package com.hsbc.layer;

public class ArrayStoreFactory {
	
	public static Book[] getStore(int size) {
		Book[] books = new Book[size];
		return books;
	}

}
