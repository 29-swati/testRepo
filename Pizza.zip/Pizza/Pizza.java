package pizzadelivery;

public class Pizza {
	String pizzaName, majorIngredientOne,majorIngredientTwo,majorIngredientThree;
	public String getPizzaName() {
		return pizzaName;
	}

	public void setPizzaName(String pizzaName) {
		this.pizzaName = pizzaName;
	}

	public String getMajorIngredientOne() {
		return majorIngredientOne;
	}

	public void setMajorIngredientOne(String majorIngredientOne) {
		this.majorIngredientOne = majorIngredientOne;
	}

	public String getMajorIngredientTwo() {
		return majorIngredientTwo;
	}

	public void setMajorIngredientTwo(String majorIngredientTwo) {
		this.majorIngredientTwo = majorIngredientTwo;
	}

	public String getMajorIngredientThree() {
		return majorIngredientThree;
	}

	public void setMajorIngredientThree(String majorIngredientThree) {
		this.majorIngredientThree = majorIngredientThree;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getSizeInCms() {
		return sizeInCms;
	}

	public void setSizeInCms(int sizeInCms) {
		this.sizeInCms = sizeInCms;
	}

	float weight,price;
	int sizeInCms;
	
	public void preparation() {
		System.out.println("Cook");
	}
}