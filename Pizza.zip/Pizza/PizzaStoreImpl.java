package pizzadelivery;

public class PizzaStoreImpl implements PizzaStore{

	private static Pizza[] pizzadata = new Pizza[100];
	private static int count=0;
	@Override
	public void addNewPizza(Pizza e) throws PizzaAlreadyExistsException {
		for(int i=0;i<=count;i++)
			if(pizzadata[i].getPizzaName().equals(e.getPizzaName()))
				throw new PizzaAlreadyExistsException();
		pizzadata[count++]=e;
		System.out.println("Pizza request has been processed and added");
	}

	@Override
	public Pizza getPizzaByName(String pizzaname) throws NoPizzaFoundException {
		for(Pizza p:pizzadata) {
			if(p.getPizzaName().equals(pizzaname))
				return p;
		}
		throw new NoPizzaFoundException();
	}

	@Override
	public Pizza[] getPizzaNamesBySize(int size) {
		Pizza []p=new Pizza[100];
		int i=0;
		for(Pizza p1:pizzadata) {
			if(p1.getSizeInCms()==size)
				p[i++]=p1;
		}
		return p;
	}


}

