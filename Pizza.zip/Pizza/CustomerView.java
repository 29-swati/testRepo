package pizzadelivery;

import java.io.IOException;

public class CustomerView {
	void addPizzaDetailsAndStore() throws PizzaAlreadyExistsException, IOException {
		Pizza pizza=new Pizza();
		pizza.setMajorIngredientOne("maida");
		pizza.setMajorIngredientTwo("cheeze");
		pizza.setMajorIngredientThree("pepper");
		pizza.setPizzaName("extravaganza");
		pizza.setPrice(353);
		pizza.setSizeInCms(25);
		pizza.setWeight(0.4f);
		PizzaStore ps=new PizzaStoreImpl();
		ps.addNewPizza(pizza);
	}	
	void displayPizzaDetailsByName() throws NoPizzaFoundException {
		PizzaStoreImpl psi = new PizzaStoreImpl();		
		Pizza p=psi.getPizzaByName("extravaganza");
		System.out.println(p.getMajorIngredientOne());
		System.out.println(p.getMajorIngredientTwo());
		System.out.println(p.getMajorIngredientThree());
		System.out.println(p.getPizzaName());
		System.out.println(p.getPrice());
		System.out.println(p.getSizeInCms());
		System.out.println(p.getWeight());	
	}
	
	void printPizzaNamesBySize() {
		PizzaStoreImpl psi = new PizzaStoreImpl();	
		Pizza p[]=psi.getPizzaNamesBySize(25);
		for(Pizza p1:p) {
			System.out.println(p1.getMajorIngredientOne());
			System.out.println(p1.getMajorIngredientTwo());
			System.out.println(p1.getMajorIngredientThree());
			System.out.println(p1.getPizzaName());
			System.out.println(p1.getPrice());
			System.out.println(p1.getSizeInCms());
			System.out.println(p1.getWeight());		
		}
		
	}
	public static void main(String[] args) throws PizzaAlreadyExistsException, IOException {
		CustomerView c=new CustomerView();
		c.addPizzaDetailsAndStore();
		
	}
}

