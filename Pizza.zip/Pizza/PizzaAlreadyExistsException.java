package pizzadelivery;

public class PizzaAlreadyExistsException extends Exception {
    public PizzaAlreadyExistsException(){
    super();
    System.out.println("Pizza Already exists");
    }

    public PizzaAlreadyExistsException(String message){
        super(message);
        }
}


