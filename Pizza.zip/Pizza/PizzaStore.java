package pizzadelivery;

import java.io.IOException;

public interface PizzaStore {
	public void addNewPizza(Pizza e) throws PizzaAlreadyExistsException, IOException ;
	public Pizza getPizzaByName(String pizzaname)throws NoPizzaFoundException, IOException, ClassNotFoundException, IOException;
	public Pizza[] getPizzaNamesBySize(int size)throws NoPizzaFoundException, ClassNotFoundException, IOException;
}
