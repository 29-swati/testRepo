package pizzadelivery;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class PizzaStoreFileImpl implements PizzaStore {

	private static int count=0;
	@Override
	public void addNewPizza(Pizza e) throws PizzaAlreadyExistsException, IOException {
		FileOutputStream fout= new FileOutputStream("C:\\Users\\91834\\Desktop\\pizza.txt");
		ObjectOutputStream Oos = new ObjectOutputStream(fout);
		Oos.writeObject(e);
	}

	@Override
	public Pizza getPizzaByName(String pizzaname) throws NoPizzaFoundException, IOException, ClassNotFoundException {
		FileInputStream fis = new FileInputStream("C:\\Users\\91834\\Desktop\\pizzaStore.txt");
		ObjectInputStream Ois = new ObjectInputStream(fis);
		Pizza p =(Pizza)Ois.readObject();
		if(p.getPizzaName().equals(pizzaname))
			return p;
		throw new NoPizzaFoundException();
	}

	@Override
	public Pizza[] getPizzaNamesBySize(int size) throws ClassNotFoundException, IOException {
		FileInputStream fis = new FileInputStream("C:\\Users\\91834\\Desktop\\pizzaStore.txt");
		ObjectInputStream Ois = new ObjectInputStream(fis);
		Pizza p[] =new Pizza[100];
		p[0]=(Pizza)Ois.readObject();
		if(p[0].getSizeInCms()==size)
			return p;
		return null;
	}
}