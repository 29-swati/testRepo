package pizzadelivery;

public class PizzaStoreFactory {
	public static PizzaStoreImpl getPizzaStore() {
		PizzaStoreImpl pi=new PizzaStoreImpl();
		return pi;	
	}
	
	public PizzaStoreFileImpl getPizzaFileStore() {
		PizzaStoreFileImpl pf=new PizzaStoreFileImpl();
		return pf;
	}
}
