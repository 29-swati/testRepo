package pizzadelivery;
public class NoPizzaFoundException extends Exception {
    public NoPizzaFoundException(){
        super();
        System.out.println("Pizza not found");
    }

    public NoPizzaFoundException(String message){
        super(message);
    }
}
