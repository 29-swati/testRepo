package com.hsbc;

public class Book {
	private int bookId;
	private String bname, author;
	private double price;
	private static int counter;
	

	public Book(int bookId, String bname, String author, double price) {
		this.bookId = bookId;
		this.bname = bname;
		this.author = author;
		this.price = price;
	}

	public Book() {}

	public void displayDetails() {
		System.out.println("Book [bookId=" + bookId + ", bname=" + bname + ", author=" + author + ", price=" + price + "]");
	}
	
	public void incrPrice(double per) {
		this.price = this.price + (this.price * per/100);
	}

	public int getBookId() {
		return bookId;
	}

	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bname=" + bname + ", author=" + author + ", price=" + price + "]";
	}
	
	

}
