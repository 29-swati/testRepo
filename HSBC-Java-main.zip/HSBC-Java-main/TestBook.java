package com.hsbc;

import java.util.Arrays;

public class TestBook {
	public static void main(String[] args) {
		Book b1 = new Book(1001, "Core Java", "Kishori S", 450.0);
		
		Book[] books = {
						new Book(1001, "Book-1", "author-1", 450.0),
						new Book(1002, "Book-2", "author-2", 400.0),
						new Book(1003, "Book-3", "author-3", 200.0)
						};
		
		int bid = 1002;
		boolean flag = false;
		Book foundBook = null;
		
		for(Book book : books) {
			if(book.getBookId() == bid) {
				flag = true;
				foundBook = book;
				break;
			}
		}
		
		if(flag)
			System.out.println(foundBook);
		
		for(Book book : books) {
			book.incrPrice(5);
		}
		
		System.out.println(Arrays.toString(books));
		

	}
}
