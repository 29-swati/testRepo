package com.hsbc;

import java.util.Arrays;

public class StringDemo {
	
	public static void main(String[] args) {
		
		String s1 = "Hello World";
		
		System.out.println(s1.length());    //11
		System.out.println(s1.charAt(7));   //o
		System.out.println(s1.indexOf("r"));   //8
		System.out.println(s1.indexOf("orl"));   //7
		System.out.println(s1.toUpperCase());
		
		String s2 = "Pranav#Pavan#Sneha#Garima";
		
		String[] sarr = s2.split("#");
		for(String str : sarr)
			System.out.println(str);
		
		
		
				
	}

}
