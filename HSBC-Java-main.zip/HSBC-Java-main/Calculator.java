package com.hsbc;

public class Calculator {
	//Method overloading  -> static polymorphism
	//same class, same method name
	//type of para or no of para must be diff
	//return type has no significance
	
	public static int add(int a , int b) {
		return a + b;
	}
	
	public static String add(String a , String b) {
		return a + b;
	}
	
	public static float add(float a, float b) {
		return a + b;
	}
	
	public static int add(int a , int b, int c) {
		return a + b + c;
	}
	
}
