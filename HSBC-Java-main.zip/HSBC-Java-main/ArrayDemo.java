package com.hsbc;

public class ArrayDemo {

	public static void main(String[] args) {

		// int arr[] = new int[5];
		int[] arr = { 10, 20, 30, 40 };

		// float[] farr = new float[10];
		float farr[] = { 10.2f, 21.7f, 34.8f };

		for (float f : farr)
			System.out.println(f + 10);

		char[] carr = { 'a', '$', '*', '|', '7' };

		for (char ch : carr)
			System.out.println(ch);

		/*
		 * String[] sarr = new String[3]; sarr[0]="Nupur"; sarr[1]="Pavan";
		 * sarr[2]="Gowtham";
		 */
		String[] sarr = { "aaaa", "bbbb", "ccccc" };

		for (String name : sarr)
			System.out.println(name);

		// 2-dimensional array
		int k = 100;
		int[][] marr = new int[2][3];
		for (int i = 0; i < marr.length; i++) {
			for (int j = 0; j < marr[i].length; j++) {
				marr[i][j] = k;
				k++;
			}
		}

		
		// int[][] marr = {{10,20, 30}, {40,50, 60}};
		for (int i = 0; i < marr.length; i++) {
			for (int j = 0; j < marr[i].length; j++) {
				System.out.print(marr[i][j] + "\t");
			}
			System.out.println();
		}

	}

}
