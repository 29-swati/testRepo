package com.hsbc;

public class TestCalc {

	public static void main(String[] args) {
		
		System.out.println(Calculator.add(10, 20));
		System.out.println(Calculator.add("aaaa", "bbb"));
		System.out.println(Calculator.add(10.2f, 45.9f));
		System.out.println(Calculator.add(10,20,30));
	}

}
